from distutils.core import setup

setup(
    name = 'flipcoin',
    version = '0.0.1',
    description = 'Python wrapper for cryptocurrency markets',
    author = 'Mehmetcan Yegen',
    author_email = 'contact@mehmetcanyegen.com.tr',
    url = 'https://github.com/mehmetcanyegen/flipcoin',
    py_modules=['flipcoin'],
)
